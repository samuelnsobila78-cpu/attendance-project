#include <iostream>
#include <fstream>
#include <string>
#include <ctime>

using namespace std;

int main() {

    int choice;
    string name, id, line, date;

    // Get current date
    time_t now = time(0);
    char* dt = ctime(&now);
    date = dt;

    while(true) {

        cout << "\n===== DIGITAL ATTENDANCE SYSTEM =====" << endl;
        cout << "Date: " << date << endl;

        cout << "1. Register Student" << endl;
        cout << "2. View Students" << endl;
        cout << "3. Search Student" << endl;
        cout << "4. Mark Attendance" << endl;
        cout << "5. Exit" << endl;

        cout << "Enter choice: ";
        cin >> choice;

        // REGISTER STUDENT
        if(choice == 1) {

            cout << "Enter Student Name: ";
            cin.ignore();
            getline(cin, name);

            cout << "Enter Student ID: ";
            getline(cin, id);

            ofstream file("students.txt", ios::app);
            file << name << "," << id << endl;
            file.close();

            cout << "Student Registered Successfully!" << endl;
        }

        // VIEW STUDENTS
        else if(choice == 2) {

            ifstream file("students.txt");

            cout << "\n--- Registered Students ---" << endl;

            while(getline(file, line)) {
                cout << line << endl;
            }

            file.close();
        }

        // SEARCH STUDENT
        else if(choice == 3) {

            cin.ignore();
            cout << "Enter Student ID to Search: ";
            getline(cin, id);

            ifstream file("students.txt");
            bool found = false;

            while(getline(file, line)) {

                if(line.find(id) != string::npos) {
                    cout << "Student Found: " << line << endl;
                    found = true;
                    break;
                }
            }

            if(!found) cout << "Student Not Found!" << endl;

            file.close();
        }

        // MARK ATTENDANCE
        else if(choice == 4) {

            cin.ignore();
            cout << "Enter Student ID: ";
            getline(cin, id);

            cout << "Enter Attendance Status (P = Present, A = Absent): ";
            string status;
            getline(cin, status);

            ofstream file("attendance.txt", ios::app);
            file << date << " " << id << " " << status << endl;
            file.close();

            cout << "Attendance Recorded!" << endl;
        }

        // EXIT
        else if(choice == 5) {
            cout << "Goodbye!" << endl;
            break;
        }

        else {
            cout << "Invalid Choice!" << endl;
        }
    }

    return 0;
}
